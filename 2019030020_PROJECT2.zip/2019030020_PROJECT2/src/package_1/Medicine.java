package package_1;

import java.util.Vector;

public class Medicine {
	private int code;
	private String name;
	private float price;
	private Vector<Prescription> medPrescription;
	
	
	
	public Medicine(int mCode,String mName,float mPrice) {
		this.code=mCode;
		this.name=mName;
		this.price=mPrice;
		this.medPrescription=new Vector<Prescription>(5);
		
		
	}


	


	public int getCode() {
		return code;
	}


	public void setCode(int code) {
		this.code = code;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	public Vector<Prescription> getMedPrescription() {
		return medPrescription;
	}


	public void setMedPrescription(Vector<Prescription> medPrescription) {
		this.medPrescription = medPrescription;
	}
	public void addMedPrescription(Prescription p) {
		medPrescription.add(p);
	}
	public void printMedInfo() {
		System.out.println("Medicine name: "+this.name+", Medicine code: "+this.code+", Medicine price: "+this.price);
		
	}
	public String getMedInfo() {
		return this.name+ "," +this.code+ "," +this.price;
	}
	
	
}
