package package_1;

import java.util.Vector;
import java.util.Date;

public class Prescription {
private Date pDate;
private Date expDate;
private long preCode;
private float preCost;
private Doctor doctor;
private Insured insured;
private Vector<Medicine> listOfMedicine;


public Prescription(Date pDate,Date expDate,long pCode,float pCost,Doctor d,Insured i) {
	this.doctor=d;
	this.insured=i;
	this.listOfMedicine=new Vector<Medicine>(3);
	this.pDate=pDate;
	this.expDate=expDate;
	this.preCode=pCode;
	this.preCost=pCost;
	
}

public Date getpDate() {
	return pDate;
}

public void setpDate(Date pDate) {
	this.pDate = pDate;
}

public Date getExpDate() {
	return expDate;
}

public void setExpDate(Date expDate) {
	this.expDate = expDate;
}

public long getPreCode() {
	return preCode;
}

public void setPreCode(long preCode) {
	this.preCode = preCode;
}
public float getPreCost() {
return preCost;
}

public void setPreCost(float preCost) {
	this.preCost=preCost;
}

public Doctor getDoctor() {
	return doctor;
}

public void setDoctor(Doctor doctor) {
	this.doctor = doctor;
}

public Insured getInsured() {
	return insured;
}

public void setInsured(Insured insured) {
	this.insured = insured;
}

public Vector<Medicine> getListOfMedicine() {
	return listOfMedicine;
}

public void setListOfMedicine(Vector<Medicine> listOfMedicine) {
	this.listOfMedicine = listOfMedicine;
}
public void printPrescInfo() {
	System.out.println("Doctor:"+this.doctor+ ", Insured:"+this.insured+", Medicine:"+this.listOfMedicine);
}

public String getPrescInfo() {
	return this.doctor+ "," +this.insured+ "," +this.listOfMedicine;
}





public String getPrescriptionPeriod() {
String result = "";

result += "From: ";
result += this.pDate.toString();

result += " Until: ";
result += this.expDate.toString();

return result;	
}

}
