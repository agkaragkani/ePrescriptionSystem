package package_1;

import java.util.Vector;

public class Doctor {
	private  int aaae;
	private String firstName, lastName, specialty;
	private Vector<Prescription> docPrescriptions;;
	
	public Doctor(int aaae,String fName,String lName,String specialty) {
		this.aaae=aaae;
		this.firstName=fName;
		this.lastName=lName;
		this.specialty=specialty;
		this.docPrescriptions=new Vector<Prescription>();
	}

	public int getAaae() {
		return aaae;
	}

	public void setAaae(int aaae) {
		this.aaae = aaae;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public Vector<Prescription> getDocPrescriptions() {
		return docPrescriptions;
	}

	public void setDocPrescriptions(Vector<Prescription> docPrescriptions) {
		this.docPrescriptions = docPrescriptions;
	}
	public void addDocPrescription(Prescription p) {
		docPrescriptions.add(p);
	}
    public void printDocInfo() {
    	System.out.println("Doctor's name: "+this.firstName +this.lastName+ ",Doctor's specialty: "+this.specialty+",Doctor's AAAE: "+this.aaae);
    	
    }
    public String getDocInfo() {
    	return this.firstName+ this.lastName+ "["+this.aaae+"]";
    }
}


