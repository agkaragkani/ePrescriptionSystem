package package_1;

import java.util.Vector;

public class Insured {
private int amka;
private String firstName,lastName;
private Vector<Prescription> insPrescriptions;

public Insured(int amka,String fName,String lName) {
	this.amka=amka;
	this.firstName=fName;
	this.lastName=lName;
	this.insPrescriptions=new Vector<Prescription>();
}

public int getAmka() {
	return amka;
}

public void setAmka(int amka) {
	this.amka = amka;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public Vector<Prescription> getInsPrescriptions() {
	return insPrescriptions;
}

public void setInsPrescriptions(Vector<Prescription> insPrescriptions) {
	this.insPrescriptions = insPrescriptions;
}
public void addInsPrescription(Prescription p) {
	insPrescriptions.add(p);
}
public void printInsInfo() {
	System.out.println("Insured name: "+this.firstName +this.lastName+",Insured AMKA: "+this.amka);
}
public String getInsInfo() {
	return this.firstName+ "," +this.lastName+ "["+this.amka+"]";
}
}

