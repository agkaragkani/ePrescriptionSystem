package package_1;


import java.util.Calendar;


import java.util.Vector;


import tuc.ece.cs111.util.StandardInputRead;

import java.util.Random;
import java.util.Date;
public class OnlineFarmachy {
	private String name;
	private String url;
	private int numOfDrugs = 0;
	private int numOfDocs = 0;
	private int numOfInsured = 0;
	private int numOfPrescriptions = 0;

	private  Vector<Doctor> listOfDoctors;
	
	private Vector<Medicine> listOfMedicine;
	
	private Vector<Insured> listOfInsured;
	
	private Vector<Prescription> listOfPrescriptions;
		
	
	//CONSTUCTORS//
	
	public OnlineFarmachy() {
		listOfDoctors=new Vector<Doctor>(99);
		listOfInsured= new Vector<Insured>(99);
		listOfMedicine=new Vector<Medicine>(49);
		listOfPrescriptions=new Vector<Prescription>(399);
	}
	public OnlineFarmachy(String sName,String sUrl) {
		this.name=sName;
		this.url=sUrl;
		
		listOfDoctors=new Vector<Doctor>(99);
		listOfInsured= new Vector<Insured>(1000);
		listOfMedicine=new Vector<Medicine>(49);
		listOfPrescriptions=new Vector<Prescription>(399);
		
	}
	
	//GETTERS & SETTERS//
	
	public String getName() {
		return name;
	}
	public int getNumOfDrugs() {
		return numOfDrugs;
	}
	public void setNumOfDrugs(int numOfDrugs) {
		this.numOfDrugs = numOfDrugs;
	}
	public int getNumOfDocs() {
		return numOfDocs;
	}
	public void setNumOfDocs(int numOfDocs) {
		this.numOfDocs = numOfDocs;
	}
	public int getNumOfInsured() {
		return numOfInsured;
	}
	public void setNumOfInsured(int numOfInsured) {
		this.numOfInsured = numOfInsured;
	}
	public int getNumOfPrescriptions() {
		return numOfPrescriptions;
	}
	public void setNumOfPrescriptions(int numOfPrescriptions) {
		this.numOfPrescriptions = numOfPrescriptions;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
	
	
	public Vector<Prescription> getListOfPrescriptions() {
		return listOfPrescriptions;
	}
	public void setListOfPrescriptions(Vector<Prescription> listOfPrescriptions) {
		this.listOfPrescriptions = listOfPrescriptions;
	}
	public Vector<Doctor> getListOfDoctors() {
		return listOfDoctors;
	}
	public void setListOfDoctors(Vector<Doctor> listOfDoctors) {
		this.listOfDoctors = listOfDoctors;
	}
	public Vector<Medicine> getListOfMedicine() {
		return listOfMedicine;
	}
	public void setListOfMedicine(Vector<Medicine> listOfMedicine) {
		this.listOfMedicine = listOfMedicine;
	}
	public Vector<Insured> getListOfInsured() {
		return listOfInsured;
	}
	public void setListOfInsured(Vector<Insured> listOfInsured) {
		this.listOfInsured = listOfInsured;
	}
	
	//�������� ��������,�������,������������ ��� �������� ���� ������ ����//
	
	public void insertMedicine(Medicine m) {
		if(numOfDrugs>50) {
			System.out.println("Storage is full!No room for other drugs...");		
			}else
			
		  listOfMedicine.add(numOfDrugs, m);
			numOfDrugs++;
			}
		
	public void insertDoctor(Doctor d) {
		if(numOfDocs>100) {
			System.out.println("No more doctors are enrolled in our system....");
		}else
			
		  listOfDoctors.add(numOfDocs, d);
			numOfDocs++;
			}
		
	public void insertInsured(Insured in) {
		
		if(numOfInsured>100) {
		System.out.println("No more insured patients are enrolled in our system....");
	}else
		
	   listOfInsured.add(numOfInsured, in);
		numOfInsured++;
		}
	
	    //�������� ������������.�������,��������//
		
		public void addInsured(Insured i) {
			listOfInsured.add(i);
		}

		public void addDoctor(Doctor d) {
			listOfDoctors.add(d);
		}

		public void addMedicine(Medicine m) {
			listOfMedicine.add(m);
		}
	
	
		//������ ��������� �������� �� ���� ������� ���� �������//
		
	public Vector<Medicine> findNumOfMedByCode() {
		int maxMedicine=4;
		StandardInputRead sir = new StandardInputRead();
		int w;
		Vector<Medicine> medicine=new Vector<Medicine>(3);
	
	int i=0;
	while(i<maxMedicine) {
		Medicine m=findMedicineByCode(sir.readPositiveInt("Give medicine's code:"));
		medicine.add(m);
		w=sir.readPositiveInt("Do you want more medicine?If not press 0...");
		if(w!=0) {
			i++;
			}else {
				break;
			}
			}
			return medicine;	
	}
	
	
	
		
	
	
	//������ ��������� �������� �� ���� ������� ���� ��������//
	
public Vector<Medicine> findNumOfMedByName() {
	
        int maxMedicine=4;
		StandardInputRead sir = new StandardInputRead();
		int i=0;
		int w=0;
		Medicine med;
		Vector<Medicine> medicine=new Vector<Medicine>(3);
        
		
		while(i<maxMedicine) {
				med=findMedicineByName(sir.readString("Give medicine's name: "));
				medicine.add(med);
				w=sir.readPositiveInt("Do you want more medicine?If not press 0...");
				if(w!=0) {
					i++;
					}else {
						break;
					}
					}
					return medicine;
			   
}
	public String getPeriod(Date pDate,Date expDate) {
		
	
		
		
	   
	    String result = "";

	    result += "From: ";
	    result += pDate.toString();

	    result += " Until: ";
	    result += expDate.toString();

	    return result;	
	}
	public float getPresCost() {
		int medQuantity=4;
		float price=0;
		float sum=0;
		for(int i=0;i<=medQuantity;i++) {
			price=listOfMedicine.get(i).getPrice();
			sum +=price;
		}
		return sum;
	}
	
	

	public void addNewPrescription(Doctor d,Insured i,Vector<Medicine> medicine) {
		StandardInputRead sir = new StandardInputRead();
        
		
		
		Date pDate;
		Date expDate;
		
	if(d!=null && i!=null) {	
	   
		Calendar c = Calendar.getInstance(); 

	       
		pDate=sir.readDate("Give the date that the prescription was made:");
		
        c.setTime(pDate);
		
	    c.add(Calendar.DATE, +10);
	    
	    expDate=c.getTime();
	    
	   
		
	    Random randomGenerator=new Random();
	    
	   long preCode=randomGenerator.nextLong();
	   
	   float totalCost=getPresCost();
	   
	  
			             
				
								
			Prescription p=new Prescription(pDate, expDate, preCode,totalCost, d, i);
			
			this.listOfPrescriptions.add(p);
			
			d.addDocPrescription(p);
			i.addInsPrescription(p);
			for(int a=0;a<medicine.size();a++) {
				medicine.get(a).addMedPrescription(p);
			}
			}
			
		else {
			System.out.println("Error: Undefined Doctor,Medicine or Insured patient...");
	}
	
}

	
	//������ ������� ���� �������� ��� ����//
	
	
	public Doctor findDoctorByAaae(int aaae) {
		for(int i=0;i<this.listOfDoctors.size();i++) {
			Doctor d=this.listOfDoctors.get(i);
			if(d.getAaae()==aaae) {
				return d;
				
				}
					
		}
		 System.out.println("Doctor not found....");
			return null;
		}
	
	
	public Doctor findDoctorByName(String fName,String lName) {
		for(int i=0;i<this.listOfDoctors.size();i++) {
			Doctor d=this.listOfDoctors.get(i);
			if(d.getFirstName().equals(fName) && d.getLastName().equals(lName)) {
				return d;
				}
					
		}
		 System.out.println("Doctor not found....");
			return null;
		}
	 
	//������ ������������ ���� ����//
	
	public Insured findInsuredByAmka(int amka) {
		for(int i=0;i<this.listOfInsured.size();i++) {
			Insured in=this.listOfInsured.get(i);
			if(in.getAmka()==amka) {
				return in;
				}
		}
		System.out.println("Insured patient not found....");
		return null;
	}
	
	
	//������ �������� ���� �������� ��� �������//
	
	public Medicine findMedicineByCode(int code) {
		for(int i=0;i<this.listOfMedicine.size();i++) {
			Medicine m=this.listOfMedicine.get(i);
			if(m.getCode()==code) {
				return m;
				}
		}
		System.out.println("Medicine not found....");
		return null;
	}
	
	public Medicine findMedicineByName(String name) {
		for(int i=0;i<this.listOfMedicine.size();i++) {
			Medicine m=this.listOfMedicine.get(i);
			if(m.getName().equals(name)){
				return m;
				}
		}
		System.out.println("Medicine not found....");
		return null;
	}
	
	
	//������ ��� �������� �������� ���� ��������,����,����,������� ��������//
	
	public void findPrescriptionByDate(Date start,Date end) {
		for(int i=0;i<this.listOfPrescriptions.size();i++) {
			Prescription p=this.listOfPrescriptions.get(i);
			if(p.getpDate().compareTo(start)*p.getExpDate().compareTo(end)>0) {
				  listOfPrescriptions.get(i).printPrescInfo();
				}
		}
	}
	
	public void findPrescriptionByDoctor(int aaae) {
		Doctor d = findDoctorByAaae(aaae);
		if(d!=null) {
			System.out.println("Prescriptions of Doctor " + d.getDocInfo());
			if(d.getDocPrescriptions().size()>0) {
				for (int i = 0; i < d.getDocPrescriptions().size(); i++) {
					Prescription p = d.getDocPrescriptions().get(i);
					p.printPrescInfo();
				}
			} else {
				System.out.println("There are no prescriptions for this doctor...");
			}
	}
	}
	
	public void findPrescriptionByInsured(int amka) {
		Insured in = findInsuredByAmka(amka);
		if(in!=null) {
			System.out.println("Preescriptions of patient " + in.getInsInfo());
			if(in.getInsPrescriptions().size()>0) {
				for (int i = 0; i <in.getInsPrescriptions().size(); i++) {
					Prescription p = in.getInsPrescriptions().get(i);
					p.printPrescInfo();
				}
			} else {
				System.out.println("There are no prescriptions for this patient...");
			}
	}
	
	}
	
	public void findPrescriptionByMedcode(int code) {
		Medicine m = findMedicineByCode(code);
		if(m!=null) {
			System.out.println("Prescriptions of medicine" + m.getMedInfo());
			if(m.getMedPrescription().size()>0) {
				for (int i = 0; i <m.getMedPrescription().size(); i++) {
					Prescription p = m.getMedPrescription().get(i);
					p.printPrescInfo();
				}
			} else {
				System.out.println("There are no prescriptions for this patient...");
			}
	}
		
		
	}
	
	//�������� ���������//
	public void printPrescriptionCatalogue() {
		for(int i=0;i< this.listOfPrescriptions.size();i++) {
		listOfPrescriptions.get(i).printPrescInfo();		}
	}
	
	public void printInsuredCatalogue() {
		for(int i=0;i< this.listOfInsured.size();i++) {
			listOfInsured.get(i).printInsInfo();	}
		
	}
	
	public void printDoctorsCatalogue() {
		for(int i=0;i< this.listOfDoctors.size();i++) {
			listOfDoctors.get(i).printDocInfo();	}
		
	}
	
	public void printMedicineCatalogue() {
		for(int i=0;i< this.listOfMedicine.size();i++) {
			listOfMedicine.get(i).printMedInfo();	}
		
	}
	
	//�������� ������ ��� �������� ���//
	
	public void deleteInsured(int amka) {
		for(int i=0;i<this.listOfInsured.size();i++) {
			  if(listOfInsured.get(i).getAmka()==amka) {
			  listOfInsured.remove(i);
			  listOfPrescriptions.remove(i);
			  
			  
			 
			  
				}
		}
	}
		
}


